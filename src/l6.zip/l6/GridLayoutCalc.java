package l6;

import javax.swing.*;
import java.awt.*;

public class GridLayoutCalc extends JFrame {

    public GridLayoutCalc() {
        super("GridLayoutCalc");

        setSize(100, 100);
        setLocation(300, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
// Вспомогательная панель
        JPanel grid = new JPanel();
        /*
         * Первые два параметра конструктора GridLayout определяют количество
         * строк и столбцов в таблице. Вторые 2 параметра -- расстояние между
         * ячейками по горизонтали и вертикали
         */
        GridLayout layout = new GridLayout(2, 0, 3, 12);
        grid.setLayout(layout);
// Создаем 8 кнопок
        for (int i = 0; i <= 9; i++) {
            grid.add(new JButton("" + i));
        }
// Размещаем нашу панель в панели содержимого
        getContentPane().add(grid);
// Устанавливаем оптимальный размер окна
        pack();
// Открываем окно
        setVisible(true);

    }

    public static void main(String[] args) {
        new GridLayoutCalc();
    }

}
